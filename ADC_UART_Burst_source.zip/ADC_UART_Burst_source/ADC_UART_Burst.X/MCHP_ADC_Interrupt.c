#include "ADC_UART_Burst.h"
#include "ADC_UART_Burst_private.h"

void __attribute__((interrupt(IPL2SOFT), vector(_ADC_DF1_VECTOR)))
  ADC_DF1_VECTOR_Handler(void)
{
  {
    struct {
      unsigned int Flags1 : 1;
    } static volatile Overrun ;

    struct {
      unsigned int Flags1 : 1;
    } static volatile event ;

    struct {
      uint_T Task1;                  /* 0.1s periodic task. Max value is 1000 */
    } static volatile taskCounter = {
      .Task1 = 1    /* Offset is 0 (-1000 + 1 modulo [1000 for pre decrement) */
    };

    {
      register unsigned int tmp = ADCFLTR1;
    }                                  /* Remove cause of Interrupt */

    {
      register unsigned int tmp = ADCCON2;
    }                                  /* Remove cause of Interrupt */

    IFS1CLR = 0x00100000;              /* _ADCDF1IF = 0 Re-enable interrupt */

    /* Check subrate overrun, set rates that need to run this time step*/
    taskCounter.Task1--;               /* Decrement task internal counter */
    if (taskCounter.Task1 == 0) {      /* task dropped on overload */
      taskCounter.Task1 = (uint_T) 1000;
                                     /* 0.1s periodic task. Max value is 1000 */
      event.Flags1 = 1U;               /* Flag tag to be executed */
    }

    /* ---------- Handle model base rate Task 0 ---------- */
    ADC_UART_Burst_step0();

    /* Get model outputs here */
    if (IFS1bits.ADCDF1IF ) {
      return;                          /* Will re-enter into the interrupt */
    }

    /* Re-Enable Interrupt. IPL value is 2 at this point */
    __builtin_set_isr_state(8 + 1);
    /* Re-Enable Scheduler re-entrant interrupt. Lower IPL from 2 to 1 ; keep bit ei set */

    /* Step the model for any subrate */
    /* ---------- Handle Task 1 ---------- */
    if (Overrun.Flags1) {
      return;                    /* Priority to higher rate steps interrupted */
    }

    if (event.Flags1) {
      Overrun.Flags1 = 1;
      do {                             /* Execute task tid 1 */
        event.Flags1 = 0U;
        ADC_UART_Burst_step1();

        /* Get model outputs here */
      } while (event.Flags1);

      Overrun.Flags1 = 0U;
    }

    /* Disable Interrupt. IPL value is 1 at this point */
    __builtin_set_isr_state(8 + 2);
       /* Disable Scheduler Interrupts. Rise IPL from 1 to 2; keep bit ei set */
  }
}
