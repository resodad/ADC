#include "ADC_UART_Burst.h"
#include "ADC_UART_Burst_private.h"

MCHP_UART4_RxStr MCHP_UART4_Rx = { .head = 0, .tail = 0 };/* UART4 Rx FIFO */

void __attribute__((interrupt(IPL5SRS), no_fpu, vector(_UART4_RX_VECTOR)))
  UART4_RX_VECTOR_Handler(void)
{
  uint_T Tmp;
  Tmp = ~(MCHP_UART4_Rx.tail - MCHP_UART4_Rx.head);/* head - tail - 1 */
  Tmp &= (Rx_BUFF_SIZE_UART4-1);
  /* Tmp =  (head - tail - 1) modulo buffersize Rx_BUFF_SIZE_UART4) ; tmp <~ Rx_BUFF_SIZE_UART4 - (head - tail) - 1*/
  while (U4STAbits.URXDA == 1) {
    if (Tmp--) {
      MCHP_UART4_Rx.buffer[MCHP_UART4_Rx.tail] = (uint8_T) U4RXREG;
      MCHP_UART4_Rx.tail = (MCHP_UART4_Rx.tail+1) & (Rx_BUFF_SIZE_UART4-1);
    } else {
      unsigned int a;
      do
        a = U4RXREG;
      while (U4STAbits.URXDA == 1);
      break;
    }
  }

  IFS5CLR = 0x0800;                    /* _U4RXIF = 0  */
  if (U4STAbits.OERR == 1)
    U4STAbits.OERR = 0;                /* Buffer Overflow cleared */
}
