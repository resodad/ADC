/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * -------------------------------------------------------------------
 * MPLAB 16-Bit Device Blocks for Simulink v3.46 (08-Nov-2019)
 *
 *   Product Page:  http://www.microchip.com/SimulinkBlocks
 *           Forum: http://www.microchip.com/forums/f192.aspx
 *           Wiki:  http://microchip.wikidot.com/simulink:start
 * -------------------------------------------------------------------
 * File: ADC_UART_Burst.h
 *
 * Code generated for Simulink model 'ADC_UART_Burst'.
 *
 * Model version                  : 1.138
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Fri Sep 18 11:13:31 2020
 */

#ifndef RTW_HEADER_ADC_UART_Burst_h_
#define RTW_HEADER_ADC_UART_Burst_h_
#include <string.h>
#ifndef ADC_UART_Burst_COMMON_INCLUDES_
# define ADC_UART_Burst_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* ADC_UART_Burst_COMMON_INCLUDES_ */

#include "ADC_UART_Burst_types.h"
#define FCY                            (200000000U)              /* Instruction Frequency FCY set at  200.0 MHz */

/* Include for pic 32M */
#include <xc.h>

/* Peripheral Clock BUS setting (for use with custom code) */
#define PBCLK1                         (100000000U)              /* PBCLK1 set at  100.0 MHz */
#define PBCLK2                         (100000000U)              /* PBCLK2 set at  100.0 MHz */
#define PBCLK3                         (100000000U)              /* PBCLK3 set at  100.0 MHz */
#define PBCLK4                         (200000000U)              /* PBCLK4 set at  200.0 MHz */
#define PBCLK5                         (100000000U)              /* PBCLK5 set at  100.0 MHz */
#define PBCLK7                         (200000000U)              /* PBCLK7 set at  200.0 MHz */
#define PBCLK8                         (100000000U)              /* PBCLK8 set at  100.0 MHz */

/* Macros for accessing real-time model data structure */
#ifndef rtmCounterLimit
# define rtmCounterLimit(rtm, idx)     ((rtm)->Timing.TaskCounters.cLimit[(idx)])
#endif

#ifndef rtmStepTask
# define rtmStepTask(rtm, idx)         ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmTaskCounter
# define rtmTaskCounter(rtm, idx)      ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

/* Block signals and states (default storage) for system '<Root>' */
typedef struct {
  int16_T U4CH1;
  /* '<Root>/Step frequency MAX: Clock // 8 MIN governed by 32 bit counter Burst sample works set convert at end of prev time step' */
  int16_T U4CH2;
  /* '<Root>/Step frequency MAX: Clock // 8 MIN governed by 32 bit counter Burst sample works set convert at end of prev time step' */
  uint8_T Output_DSTATE;               /* '<S3>/Output' */
} DW_ADC_UART_Burst_T;

/* Constant parameters (default storage) */
typedef struct {
  /* Computed Parameter: Vector_Value
   * Referenced by: '<S2>/Vector'
   */
  boolean_T Vector_Value[19];
} ConstP_ADC_UART_Burst_T;

/* Real-time Model Data Structure */
struct tag_RTM_ADC_UART_Burst_T {
  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    struct {
      uint16_T TID[2];
      uint16_T cLimit[2];
    } TaskCounters;
  } Timing;
};

/* Block signals and states (default storage) */
extern DW_ADC_UART_Burst_T ADC_UART_Burst_DW;

/* Constant parameters (default storage) */
extern const ConstP_ADC_UART_Burst_T ADC_UART_Burst_ConstP;

/* Model entry point functions */
extern void ADC_UART_Burst_initialize(void);
extern void ADC_UART_Burst_step0(void);
extern void ADC_UART_Burst_step1(void);

/* Real-time Model object */
extern RT_MODEL_ADC_UART_Burst_T *const ADC_UART_Burst_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S3>/Data Type Propagation' : Unused code path elimination
 * Block '<S4>/FixPt Data Type Duplicate' : Unused code path elimination
 * Block '<S5>/FixPt Data Type Duplicate1' : Unused code path elimination
 * Block '<S2>/Out' : Eliminate redundant signal conversion block
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'ADC_UART_Burst'
 * '<S1>'   : 'ADC_UART_Burst/LED flash'
 * '<S2>'   : 'ADC_UART_Burst/LED flash/Morse B'
 * '<S3>'   : 'ADC_UART_Burst/LED flash/Morse B/LimitedCounter'
 * '<S4>'   : 'ADC_UART_Burst/LED flash/Morse B/LimitedCounter/Increment Real World'
 * '<S5>'   : 'ADC_UART_Burst/LED flash/Morse B/LimitedCounter/Wrap To Zero'
 */
#endif                                 /* RTW_HEADER_ADC_UART_Burst_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
