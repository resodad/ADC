/******************************************************/
/* This file includes simulink model public .h files. */
/* File name will not depends on model's name 	      */
/* simplifying inclusion for your shared c/h added    */
/* code (if any)  	                                  */
/******************************************************/

#include "ADC_UART_Burst.h"
#include "ADC_UART_Burst_private.h"
