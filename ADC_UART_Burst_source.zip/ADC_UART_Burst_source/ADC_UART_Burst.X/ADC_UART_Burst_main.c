/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * -------------------------------------------------------------------
 * MPLAB 16-Bit Device Blocks for Simulink v3.46 (08-Nov-2019)
 *
 *   Product Page:  http://www.microchip.com/SimulinkBlocks
 *           Forum: http://www.microchip.com/forums/f192.aspx
 *           Wiki:  http://microchip.wikidot.com/simulink:start
 * -------------------------------------------------------------------
 * File: ADC_UART_Burst_main.c
 *
 * Code generated for Simulink model 'ADC_UART_Burst'.
 *
 * Model version                  : 1.138
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Fri Sep 18 11:13:31 2020
 */

#define MCHP_isMainFile
#include "ADC_UART_Burst.h"
#include "ADC_UART_Burst_private.h"

/* Microchip Global Variables */
/* Set Fuses Options */

#pragma config FPLLIDIV = DIV_3, FPLLRNG = RANGE_5_10_MHZ, FPLLICLK = PLL_POSC, FPLLMULT = MUL_50, FPLLODIV = DIV_2
#pragma config FNOSC = POSC, FSOSCEN = OFF, POSCMOD = EC, WDTSPGM = STOP, FWDTEN = OFF, FDMTEN = OFF
#pragma config JTAGEN = OFF

int main()
{
  /* Initialize model */

  /* Start Clock Switching */
  if (OSCCONbits.COSC == 1)     /* check not already in PLL mode (001 = SPLL) */
  {
    SYSKEY = 0x0;                      /* Ensure OSCCON is locked */
    SYSKEY = 0xAA996655;               /* write Key1 unlock sequence */
    SYSKEY = 0x556699AA;               /* write Key2 unlock sequence */
    OSCCONCLR &= 0x0500;          /* switch to HS - EC Oscillator without PLL */
    OSCCONSET = 0x0200;
    OSCCONSET = 1;                     /* Start clock switching */
    SYSKEY = 0x0;                      /* OSCCON is relocked */
    while (OSCCONbits.OSWEN != 0) ;    /* wait for clock stabilization */
  }

  /* Set FRCDIV */
  SPLLCON = 0x01310201;
          /* configure PLL : PLLODIV ; PLLMULT ; PLLIDIV ; PLLICLK ; PLLRANGE */

  /* switch to PLL input (SPLL) */
  SYSKEY = 0x0;                        /* Ensure OSCCON is locked */
  SYSKEY = 0xAA996655;                 /* write Key1 unlock sequence */
  SYSKEY = 0x556699AA;                 /* write Key2 unlock sequence */
  OSCCONCLR = 0x07000600;
  OSCCONSET = 0x0100;
  OSCCONSET = 1;                       /* Start clock switching */
  SYSKEY = 0x0;                        /* OSCCON is relocked */

  /* Configure Pins as Analog or Digital */
  ANSELG = 0x03C0;

  /* Configure Remappables Pins */
  U4RXR = 0x0B;
  RPF8R = 0x02;

  /* Configure Digitals I/O directions */
  TRISF = 0xFEFF;
  TRISG = 0x7FFF;

  /* Finish clock switching procedure */
  while (OSCCONbits.OSWEN != 0) ;      /* wait for clock stabilization */
  SYSKEY = 0x0;                        /* Ensure OSCCON is locked */
  SYSKEY = 0xAA996655;                 /* write Key1 unlock sequence */
  SYSKEY = 0x556699AA;                 /* write Key2 unlock sequence */
  PB1DIV = 0x8001;                     /* PBCLK1 set at  100.0 MHz */
  PB2DIV = 0x8001;                     /* PBCLK2 set at  100.0 MHz */
  PB3DIV = 0x8001;                     /* PBCLK3 set at  100.0 MHz */
  PB4DIV = 0x8000;                     /* PBCLK4 set at  200.0 MHz */
  PB5DIV = 0x8001;                     /* PBCLK5 set at  100.0 MHz */
  PB7DIV = 0x8000;                     /* PBCLK7 set at  200.0 MHz */
  PB8DIV = 0x8001;                     /* PBCLK8 set at  100.0 MHz */
  SYSKEY = 0x0;                        /* OSCCON is relocked */

  /* Configure Wait State : Flash PM Wait States for Flash -> 2 wait states @ 200.0 MHz*/
  PRECON = 0x32;
    /* Prefetch-cache: Enable prefetch for PFM (any PFM instructions or data) */

  /* Configure Interrupt */
  PRISS = 0x76543210;
      /* Each interrupt will use shadow registers ; PRIxSS = x with x in [1-7]*/
  INTCONbits.MVEC = 1;                 /* Use vector table */

  /* Initialize model */
  ADC_UART_Burst_initialize();

  /* Configure Timers */
  /* --- TIMER 1 --- This timer is enabled at end of configuration functions. */
  T1CON = 0;                      /* Stop Timer 1 and resets control register */
  PR1 = 0x270F;                        /* Period */

  /* Configure Interrupt */
  __asm__ volatile("ei");              /* Enable Global Interrupt */

  /* Enable Time-step */
  TMR1 = 0x270E;                       /* Initialize Timer Value */
  T1CONSET = 0x8000;
      /* Start timer 1. Timer 1 is the source trigger for the model Time-step */

  /* Main Loop */
  for (;;) ;
}                                      /* end of main() */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
