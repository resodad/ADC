/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * -------------------------------------------------------------------
 * MPLAB 16-Bit Device Blocks for Simulink v3.46 (08-Nov-2019)
 *
 *   Product Page:  http://www.microchip.com/SimulinkBlocks
 *           Forum: http://www.microchip.com/forums/f192.aspx
 *           Wiki:  http://microchip.wikidot.com/simulink:start
 * -------------------------------------------------------------------
 * File: ADC_UART_Burst_data.c
 *
 * Code generated for Simulink model 'ADC_UART_Burst'.
 *
 * Model version                  : 1.138
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Fri Sep 18 11:13:31 2020
 */

#include "ADC_UART_Burst.h"
#include "ADC_UART_Burst_private.h"

/* Constant parameters (default storage) */
const ConstP_ADC_UART_Burst_T ADC_UART_Burst_ConstP = {
  /* Computed Parameter: Vector_Value
   * Referenced by: '<S2>/Vector'
   */
  { 1, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
