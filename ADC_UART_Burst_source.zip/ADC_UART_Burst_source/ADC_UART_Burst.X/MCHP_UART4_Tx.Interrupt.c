#include "ADC_UART_Burst.h"
#include "ADC_UART_Burst_private.h"

/* Declare UART4 Tx Circular Buffer Structure */
MCHP_UART4_TxStr MCHP_UART4_Tx = { .head = 0, .tail = 0 };/* UART4 Tx FIFO */

void __attribute__((interrupt(IPL5SRS), no_fpu, vector(_UART4_TX_VECTOR)))
  UART4_TX_VECTOR_Handler(void)
{
  register uint_T LocalHead;
  LocalHead = MCHP_UART4_Tx.head;
     /* Head is a volatile variable. Use local variable to speed-up execution */
  while ((0U == U4STAbits.UTXBF) && (MCHP_UART4_Tx.tail != LocalHead) )/* while UxTXREG buffer is not full */
  {
    U4TXREG = MCHP_UART4_Tx.buffer[LocalHead];
    LocalHead = (LocalHead + 1) & (Tx_BUFF_SIZE_UART4-1);
  }

  if (MCHP_UART4_Tx.tail == LocalHead) {
    IEC5CLR = 0x1000;                  /* _U4TXIE = 0  */
  }

  MCHP_UART4_Tx.head = LocalHead;      /* Push back volatile variable */
  IFS5CLR = 0x1000;                    /* _U4TXIF = 0  */
}
