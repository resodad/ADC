/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * -------------------------------------------------------------------
 * MPLAB 16-Bit Device Blocks for Simulink v3.46 (08-Nov-2019)
 *
 *   Product Page:  http://www.microchip.com/SimulinkBlocks
 *           Forum: http://www.microchip.com/forums/f192.aspx
 *           Wiki:  http://microchip.wikidot.com/simulink:start
 * -------------------------------------------------------------------
 * File: ADC_UART_Burst_private.h
 *
 * Code generated for Simulink model 'ADC_UART_Burst'.
 *
 * Model version                  : 1.138
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Fri Sep 18 11:13:31 2020
 */

#ifndef RTW_HEADER_ADC_UART_Burst_private_h_
#define RTW_HEADER_ADC_UART_Burst_private_h_
#include "rtwtypes.h"

/* Declare UART4 Tx Circular Buffer Structure */
extern MCHP_UART4_TxStr MCHP_UART4_Tx;
extern MCHP_UART4_RxStr MCHP_UART4_Rx;

#endif                                /* RTW_HEADER_ADC_UART_Burst_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
