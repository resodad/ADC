/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * -------------------------------------------------------------------
 * MPLAB 16-Bit Device Blocks for Simulink v3.46 (08-Nov-2019)
 *
 *   Product Page:  http://www.microchip.com/SimulinkBlocks
 *           Forum: http://www.microchip.com/forums/f192.aspx
 *           Wiki:  http://microchip.wikidot.com/simulink:start
 * -------------------------------------------------------------------
 * File: ADC_UART_Burst_types.h
 *
 * Code generated for Simulink model 'ADC_UART_Burst'.
 *
 * Model version                  : 1.138
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Fri Sep 18 11:13:31 2020
 */

#ifndef RTW_HEADER_ADC_UART_Burst_types_h_
#define RTW_HEADER_ADC_UART_Burst_types_h_

/* Declare UART4 Tx Circular Buffer Structure */
#define Tx_BUFF_SIZE_UART4             (256)

typedef struct MCHP_UART4_TxStr{
  volatile uint8_T buffer[Tx_BUFF_SIZE_UART4];/* Size Rx_BUFF_SIZE_UART4 is 256 */
  volatile uint_T tail;
  /* tail is the index for the next value to be read from the Circular buffer */
  volatile uint_T head;
  /* head is the index for the next value to be written into the Circular buffer */
} MCHP_UART4_TxStr;

/* Declare UART4 Rx Circular Buffer Structure */
#define Rx_BUFF_SIZE_UART4             (256)

typedef struct MCHP_UART4_RxStr{
  volatile uint8_T buffer[Rx_BUFF_SIZE_UART4];/* Size Rx_BUFF_SIZE_UART4 is 256 */
  volatile uint_T tail;
  /* tail is the index for the next value to be written into the Circular buffer */
  uint_T head;
  /* head is the index for the next value to be read from the Circular buffer */
} MCHP_UART4_RxStr;

/* To read the UART4 Rx Circular with a custom code: read the next value: buffer[head], then increment head index by 1 modulo Rx_BUFF_SIZE_UART4 (=256).
   code example:
   if (U4STAbits.URXDA != 0)
   if (MCHP_UART4_Rx.tail != MCHP_UART4_Rx.head)	{  		// is buffer not empty ?
   output = (uint8_T) MCHP_UART4_Rx.buffer[MCHP_UART4_Rx.head ++];     // Read one char
   MCHP_UART4_Rx.head &= (Rx_BUFF_SIZE_UART4-1); 	// modulo : use a simple bitewise "and" operator as <Rx_BUFF_SIZE_UART4> is a power of 2
   }
 */

/* Forward declaration for rtModel */
typedef struct tag_RTM_ADC_UART_Burst_T RT_MODEL_ADC_UART_Burst_T;

#endif                                 /* RTW_HEADER_ADC_UART_Burst_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
