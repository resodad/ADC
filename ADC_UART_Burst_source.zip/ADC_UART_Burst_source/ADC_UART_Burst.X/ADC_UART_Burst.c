/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * -------------------------------------------------------------------
 * MPLAB 16-Bit Device Blocks for Simulink v3.46 (08-Nov-2019)
 *
 *   Product Page:  http://www.microchip.com/SimulinkBlocks
 *           Forum: http://www.microchip.com/forums/f192.aspx
 *           Wiki:  http://microchip.wikidot.com/simulink:start
 * -------------------------------------------------------------------
 * File: ADC_UART_Burst.c
 *
 * Code generated for Simulink model 'ADC_UART_Burst'.
 *
 * Model version                  : 1.138
 * Simulink Coder version         : 9.1 (R2019a) 23-Nov-2018
 * C/C++ source code generated on : Fri Sep 18 11:13:31 2020
 */

#include "ADC_UART_Burst.h"
#include "ADC_UART_Burst_private.h"

/* Block signals and states (default storage) */
DW_ADC_UART_Burst_T ADC_UART_Burst_DW;

/* Real-time model */
RT_MODEL_ADC_UART_Burst_T ADC_UART_Burst_M_;
RT_MODEL_ADC_UART_Burst_T *const ADC_UART_Burst_M = &ADC_UART_Burst_M_;

/* Model step function for TID0 */
void ADC_UART_Burst_step0(void)        /* Sample time: [0.0001s, 0.0s] */
{
  /* S-Function (MCHP_ADC_HighSpeed_SAR): '<Root>/Step frequency MAX: Clock // 8 MIN governed by 32 bit counter Burst sample works set convert at end of prev time step' */
  ADC_UART_Burst_DW.U4CH1 = (signed short int) (signed int) ADCDATA0;/* 16 lower bits */
  ADC_UART_Burst_DW.U4CH2 = ADCFLTR1;  /* Extract 16 lower bits */

  /* Update for S-Function (MCHP_UART_TxMatlab): '<Root>/UART Tx-Matlab1' */

  /* MCHP_UART_Tx-Matlab Block for UART4: <Root>/UART Tx-Matlab1/Outputs */
  {
    register char* array;
    register uint_T LocalTail = MCHP_UART4_Tx.tail;
    /* Tail is a volatile variable. Use local variable to speed-up execution */
    volatile static uint_T index = 0;
    int_T tmp;
    tmp = ~(LocalTail - MCHP_UART4_Tx.head);
    tmp = tmp & (Tx_BUFF_SIZE_UART4 - 1);/* Modulo Buffer Size */
    if (tmp > 6)
      tmp = 6;                         /* Stop condition for do-while loop*/
    do {
      switch (index) {
       case 0:                         /* CH 1 */
        tmp = tmp - 3;
        if (tmp < 0)
          break;

        {
          array = (char*) &ADC_UART_Burst_DW.U4CH1;
          MCHP_UART4_Tx.buffer[LocalTail] = 5 ;/* Control byte */
          LocalTail = (LocalTail + 1) & (Tx_BUFF_SIZE_UART4 - 1);
          MCHP_UART4_Tx.buffer[LocalTail] = array[0];
          LocalTail = (LocalTail + 1) & (Tx_BUFF_SIZE_UART4 - 1);
          MCHP_UART4_Tx.buffer[LocalTail] = array[1];
          LocalTail = (LocalTail + 1) & (Tx_BUFF_SIZE_UART4 - 1);
        }

        if (++index >= 2)
          index = 0;

       case 1:                         /* CH 2 */
        tmp = tmp - 3;
        if (tmp < 0)
          break;

        {
          array = (char*) &ADC_UART_Burst_DW.U4CH2;
          MCHP_UART4_Tx.buffer[LocalTail] = 21 ;/* Control byte */
          LocalTail = (LocalTail + 1) & (Tx_BUFF_SIZE_UART4 - 1);
          MCHP_UART4_Tx.buffer[LocalTail] = array[0];
          LocalTail = (LocalTail + 1) & (Tx_BUFF_SIZE_UART4 - 1);
          MCHP_UART4_Tx.buffer[LocalTail] = array[1];
          LocalTail = (LocalTail + 1) & (Tx_BUFF_SIZE_UART4 - 1);
        }

        if (++index >= 2)
          index = 0;
      }
    } while (tmp >= 1);         /* either buffer is full or we send all datas */

    MCHP_UART4_Tx.tail = LocalTail;    /* Push back volatile variable */

    {
      register uint_T LocalHead;
      IEC5CLR = 0x1000;
      /* _U4TXIE = 0 Disable Interrupt portecting against possible concurrent access */
      IFS5CLR = 0x1000;                /* _U4TXIF = 0 Clear Interrupt Flag */
      LocalHead = MCHP_UART4_Tx.head;
      /* Head is a volatile variable. Use local variable to speed-up execution */
      while ((0U == U4STAbits.UTXBF) && (MCHP_UART4_Tx.tail != LocalHead) )/* while UxTXREG buffer is not full */
      {
        U4TXREG = MCHP_UART4_Tx.buffer[LocalHead];
        LocalHead = (LocalHead + 1) & (Tx_BUFF_SIZE_UART4-1);
      }

      MCHP_UART4_Tx.head = LocalHead;  /* Push back volatile variable */
      if (MCHP_UART4_Tx.tail != LocalHead)
                /* If remaining values to send present in the circular buffer */
      {
        IEC5SET = 0x1000;              /* _U4TXIE = 1  Enable Interrupt */
      }
    }
  }
}

/* Model step function for TID1 */
void ADC_UART_Burst_step1(void)        /* Sample time: [0.1s, 0.0s] */
{
  /* local block i/o variables */
  boolean_T rtb_Output_c;

  /* MultiPortSwitch: '<S2>/Output' incorporates:
   *  Constant: '<S2>/Vector'
   *  UnitDelay: '<S3>/Output'
   */
  rtb_Output_c =
    ADC_UART_Burst_ConstP.Vector_Value[ADC_UART_Burst_DW.Output_DSTATE];

  /* S-Function (MCHP_Digital_Output_Write): '<S1>/LED4' */
  LATGbits.LATG15 = rtb_Output_c;

  /* Sum: '<S4>/FixPt Sum1' incorporates:
   *  Constant: '<S4>/FixPt Constant'
   *  UnitDelay: '<S3>/Output'
   */
  ADC_UART_Burst_DW.Output_DSTATE++;

  /* Switch: '<S5>/FixPt Switch' incorporates:
   *  Constant: '<S5>/Constant'
   *  UnitDelay: '<S3>/Output'
   */
  if (ADC_UART_Burst_DW.Output_DSTATE > 18) {
    ADC_UART_Burst_DW.Output_DSTATE = 0U;
  }

  /* End of Switch: '<S5>/FixPt Switch' */
}

/* Model initialize function */
void ADC_UART_Burst_initialize(void)
{
  /* Registration code */

  /* states (dwork) */
  (void) memset((void *)&ADC_UART_Burst_DW, 0,
                sizeof(DW_ADC_UART_Burst_T));

  /* Start for S-Function (MCHP_Master): '<Root>/Microchip Master' */

  /* S-Function "Microchip MASTER" initialization Block: <Root>/Microchip Master */

  /* Start for S-Function (MCHP_ADC_HighSpeed_SAR): '<Root>/Step frequency MAX: Clock // 8 MIN governed by 32 bit counter Burst sample works set convert at end of prev time step' */

  /* Reset ADC */
  ADCCON1 = 0;

  /* ADC common settings */
  ADCANCONbits.WKUPCLKCNT = 9;       /* ADC: Initialize warm up time register */
  ADCCON3bits.ADCSEL = 1;              /* Select input clock source */
  ADCCON1bits.FSSCLKEN = 1;
          /* Must be set to ensure correct funcion see DS60001344A-page 22-77 */
  ADCCON1bits.FSPBCLKEN = 1;
  /* Must be set except if ADC clock is faster than Peripheral clock to ensure correct funcion see DS60001344A-page 22-77 */
  ADCCON3bits.CONCLKDIV = 1;
                        /* Control clock frequency is fraction of input clock */
  ADCCON3bits.VREFSEL = 0;        /* Select AVdd and AVss as reference source */

  /* ADC settings by blocks */
  ADCTRGMODEbits.SH0ALT = 1;           /* ADC Input pin */
  ADCTRGMODEbits.SH1ALT = 0;           /* ADC Input pin */
  ADCTRGMODEbits.STRGEN0 = 0;          /* Presynchronized Trigger  */
  ADCTRGMODEbits.STRGEN1 = 0;          /* Presynchronized Trigger  */
  ADCTRGMODEbits.SSAMPEN0 = 0;         /* Synchronous Sampling */
  ADCTRGMODEbits.SSAMPEN1 = 0;         /* Synchronous Sampling */
  ADCIMCON1bits.SIGN0 = 1;             /* Signed / Unsigned data format */
  ADCIMCON1bits.SIGN1 = 1;             /* Signed / Unsigned data format */
  ADCCON1bits.STRGSRC = 5;             /* Scan ADC Trigger source */
  ADCTRG1bits.TRGSRC0 = 3;             /* Scan Trigger */
  ADCTRG1bits.TRGSRC1 = 3;             /* Scan Trigger */
  ;                 /* ADCCSS1bits.CSS0 = 1; 	Scan Trig for Channel 0 enabled */
  ;                 /* ADCCSS1bits.CSS1 = 1; 	Scan Trig for Channel 1 enabled */
  ADCCSS1 |= 0x03;                     /* Set Scan Trigger */
  ADCTRGSNSbits.LVL0 = 0;
                   /* Edge Trigger for individual class 1 and 2 analog inputs */
  ADCTRGSNSbits.LVL1 = 0;
                   /* Edge Trigger for individual class 1 and 2 analog inputs */
  ADC0TIMEbits.ADCDIV = 1;             /* ADC Clock Frequency */
  ADC1TIMEbits.ADCDIV = 1;             /* ADC Clock Frequency */
  ADC0TIMEbits.SAMC = 1;               /* ADC Sample Time */
  ADC1TIMEbits.SAMC = 1;               /* ADC Sample Time */
  ADC0TIMEbits.SELRES = 3;             /* ADC Resolution */
  ADC1TIMEbits.SELRES = 3;             /* ADC Resolution */
  ADCFLTR1 = 0xBC010000;  /* Use ADC Oversampling/Filter 1 for ADC Channel 1  */

  /* ADC common settings */
  ADCFLTR1bits.AFGIEN = 1;            /* Enable Interrupt for Digital Filter 1*/
  IPC13INV = ( 0x1C & (0x08 ^ IPC13) ) ;
                         /* _ADCDF1IP = 2  Set Interrupt priority for tasking */
  IFS1CLR = 0x00100000;              /* _ADCDF1IF = 0 Reset pending interrupt */
  IEC1SET = 0x00100000;
        /* _ADCDF1IE = 1  Enable Interrupt which trig the base rate time step */

  /* Turn the ADC on */
  ADCCON1bits.ON = 1;

  /* Wait for voltage reference to be stable */
  while (!ADCCON2bits.BGVRRDY) ; /* Wait until the reference voltage is ready */
  while (ADCCON2bits.REFFLT) ;
                       /* Wait if there is a fault with the reference voltage */
  ADCANCONbits.ANEN0 = 1;              /* Enable the clock to analog bias */
  ADCANCONbits.ANEN1 = 1;              /* Enable the clock to analog bias */
  while (!ADCANCONbits.WKRDY0) ;       /* Wait until ADC0 is ready */
  while (!ADCANCONbits.WKRDY1) ;       /* Wait until ADC1 is ready */
  ADCCON3bits.DIGEN0 = 1;              /* Enable ADC0 */
  ADCCON3bits.DIGEN1 = 1;              /* Enable ADC1 */

  /* Start for S-Function (MCHP_UART_Config): '<Root>/UART Configuration Pins F2 F8' */

  /* MCHP_UART_Config Block for UART 4: <Root>/UART Configuration Pins F2 F8/Initialize */
  U4BRG = 0xD8;                        /* Baud rate: 115200 (+0.01%) */
  U4MODE = 0x8008;
  U4STA = 0x5480;

  /* Configure UART4 using Tx Interruption */
  IPC43INV = ( 0x1C & (0x14 ^ IPC43) ) ;
                              /* _U4TXIP = 5   Tx Interrupt priority set to 5 */
  IFS5CLR = 0x1000;                    /* _U4TXIF = 0  */

  /* Configure UART4 Rx Interruption for <Root>/UART Configuration Pins F2 F8 */
  IPC42INV = ( 0x1C000000 & (0x14000000 ^ IPC42) ) ;
                               /* _U4RXIP = 5  Rx Interrupt priority set to 5 */
  IFS5CLR = 0x0800;                    /* _U4RXIF = 0  */
  IEC5SET = 0x0800;                    /* _U4RXIE = 1  Enable Interrupt */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
